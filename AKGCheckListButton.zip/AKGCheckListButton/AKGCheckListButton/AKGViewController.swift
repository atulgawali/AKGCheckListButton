//
//  ViewController.swift
//  AKGCheckListButton
//
//  Created by Atul Gawali on 05/02/17.
//  Copyright © 2017 Atul Gawali. All rights reserved.
//

import UIKit

class AKGViewController: UIViewController ,ProtocolDelegate{
    
    
    var akgCheckListButtonModel: [AKGCheckListButtonModel]? = nil
    var  akgRBGroupView : AKGCheckListButtonGroupView? = nil
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        setupUI()
    }
    
    func setupUI()  {
        //initialse Array
        akgCheckListButtonModel = [AKGCheckListButtonModel]()
        
        
        //make CheckListbutton object
        let croissant = AKGCheckListButtonModel(lblText : "Croissant" ,identifire : "Croissant" ,selected : true)
        let eclair = AKGCheckListButtonModel(lblText : "Éclair" ,identifire : "Éclair" ,selected : false)
        let kouignAmann = AKGCheckListButtonModel(lblText : "Kouign amann" ,identifire : "Kouign amann" ,selected : false)
        let operacake = AKGCheckListButtonModel(lblText : "Opera cake" ,identifire : "Opera cake" ,selected : false)
        let macarons = AKGCheckListButtonModel(lblText : "Macarons" ,identifire : "Macarons" ,selected : false)
        let millefeuille = AKGCheckListButtonModel(lblText : "Mille-feuille" ,identifire : "Mille-feuille" ,selected : false)
        
        akgCheckListButtonModel = [croissant,eclair,kouignAmann,operacake,macarons,millefeuille]
        
        //where you want to add jsit pass x and y point
        let size = CGPoint(x: 30, y: 130)
        
        //make view object and setup view
        
        let  akgRBGroupView = AKGCheckListButtonGroupView(akgCheckListButtonModel : akgCheckListButtonModel! ,akgCheckListButtonGroupName : "Order" , akgCheckListButtonGroupPosstion : size, selctionMode: SelctionMode.MultipleSelection)
        akgRBGroupView.setupView()
        akgRBGroupView.delegate = self
        self.view.addSubview(akgRBGroupView)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //result will got here...
    func selectedResult(resultObject:[AKGCheckListButtonModel]){
        print("Selected CheckList Button -> \(resultObject.count)")
    }
    
}

