//
//  AKGCheckListButtonModel.swift
//  AKGCheckListButton
//
//  Created by Atul Gawali on 02/02/17.
//  Copyright © 2017 Atul Gawali. All rights reserved.
//

import UIKit

class AKGCheckListButtonModel: NSObject {
  public  var lblText : String
  public  var identifire : String
  public  var selected : Bool
    
    init(lblText : String ,identifire : String ,selected : Bool){
        self.lblText = lblText
        self.identifire = identifire
        self.selected = selected
        super.init()
    }
}
