//
//  AKGCheckListButtonGroupView.swift
//  AKGCheckListButton
//
//  Created by Atul Gawali on 02/02/17.
//  Copyright © 2017 Atul Gawali. All rights reserved.
//

import UIKit
enum SelctionMode {
    case SingleSelection
    case MultipleSelection
}
protocol ProtocolDelegate {
    func selectedResult(resultObject:[AKGCheckListButtonModel])
}

class AKGCheckListButtonGroupView: UIView ,UITableViewDelegate,UITableViewDataSource{
    var akgCheckListButtonModel : [AKGCheckListButtonModel]
    var akgCheckListButtonGroupName : String
    var akgCheckListButtonGroupPosstion : CGPoint
    var selctionMode : SelctionMode
    var akgTableView : AKGTableView
    var delegate: ProtocolDelegate?
    
    init(akgCheckListButtonModel : [AKGCheckListButtonModel] ,akgCheckListButtonGroupName : String ,akgCheckListButtonGroupPosstion : CGPoint,selctionMode : SelctionMode) {
        let customHeight : CGFloat = CGFloat(akgCheckListButtonModel.count * 44) + 30
        let frame = CGRect(x: akgCheckListButtonGroupPosstion.x, y: akgCheckListButtonGroupPosstion.y, width: 200, height: customHeight)
        self.akgCheckListButtonModel = akgCheckListButtonModel
        self.akgCheckListButtonGroupName = akgCheckListButtonGroupName
        self.akgCheckListButtonGroupPosstion = akgCheckListButtonGroupPosstion
        self.selctionMode = selctionMode
        akgTableView = AKGTableView(frame: CGRect(x: 0 , y: 0, width: frame.size.width, height:frame.size.height), style: UITableViewStyle.plain)
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func setupView(){
        self.backgroundColor = UIColor.darkGray
        akgTableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        akgTableView.delegate = self
        akgTableView.dataSource = self
        akgTableView.separatorColor = UIColor.clear
        akgTableView.allowsSelection = false
        self.addSubview(akgTableView)
        
        let view1: UIView = UIView.init(frame: CGRect(x: 0, y: 0, width: akgTableView.frame.size.width, height: 30));
        let label: UILabel = UILabel.init(frame: CGRect(x: 0, y: 0, width: akgTableView.frame.size.width, height: 30))
        label.text = "  "+self.akgCheckListButtonGroupName
        view1.addSubview(label);
        akgTableView.tableHeaderView = view1;
    }
    
    func buttonAction(akgCheckListButton: UIButton!) {
        let selectedModel  = self.akgCheckListButtonModel [akgCheckListButton.tag]
        if self.selctionMode == SelctionMode.SingleSelection {
            singleSelectionCall(akgCheckListButton: akgCheckListButton)
            delegate?.selectedResult(resultObject: [selectedModel])
        }
        else{
            multipleSelectionCall(akgCheckListButton: akgCheckListButton)
            var resultObject : [AKGCheckListButtonModel] = []
            for model in self.akgCheckListButtonModel{
                if model.selected {
                    resultObject.append(model)
                }
            }
            delegate?.selectedResult(resultObject:resultObject)


          /*  let p1 = NSPredicate(format: "selected == YES")

            let objects = self.akgCheckListButtonModel.objectsWithPredicate(p1)
            print("users matching \(p1): \(objects)")*/
           
            //get all selected element in array
            //delegate?.selectedResult(resultObject: [selectedModel])

        }
    }
    func multipleSelectionCall(akgCheckListButton: UIButton!) {
        let selctedModel = self.akgCheckListButtonModel[akgCheckListButton.tag]
        if selctedModel.selected {
            selctedModel.selected = false;
        }
        else{
            selctedModel.selected = true;
        }
        akgTableView.reloadData()
    }
    
    func singleSelectionCall(akgCheckListButton: UIButton!) {
        for model in self.akgCheckListButtonModel{
            if self.akgCheckListButtonModel [akgCheckListButton.tag] .isEqual(model) {
                model.selected = true
            }
            else{
                model.selected = false
            }
        }
        akgTableView.reloadData()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return akgCheckListButtonModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:UITableViewCell=UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell")
        setupCell(cell: cell, akgModelObject: akgCheckListButtonModel [indexPath.row],indexPath: indexPath)
        return cell;
    }
    
    func setupCell(cell : UITableViewCell ,akgModelObject : AKGCheckListButtonModel ,indexPath : IndexPath){
        let akgCheckListButton = AKGCheckListButton(frame: CGRect(x: 20, y: 10, width: 150, height: 24), buttonTitle: akgModelObject.lblText, buttonTag:indexPath.row)
        akgCheckListButton.setTitle(" "+akgModelObject.lblText, for: UIControlState.normal)
        akgCheckListButton.addTarget(self, action:#selector(self.buttonAction), for: .touchUpInside)
        akgCheckListButton.contentHorizontalAlignment = .left
        akgCheckListButton.tag = indexPath.row;
        akgCheckListButton.setTitleColor(UIColor.black, for: .normal)
        if akgModelObject.selected {
            akgCheckListButton.setImage(UIImage(named: "Check"), for: UIControlState.normal)
        }
        else{
            akgCheckListButton.setImage(UIImage(named: "Uncheck"), for: UIControlState.normal)
        }
        cell.addSubview(akgCheckListButton)
    }
}


